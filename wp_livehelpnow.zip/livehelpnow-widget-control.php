 <p>
<label for="livehelpnow_clientid">LiveHelpNow Account # <input name="livehelpnow_clientid"
type="text" value="<?php echo $livehelpnow_clientid; ?>" /></label></p>
<p><label for="livehelpnow_buttonid">LiveHelpNow Button # <input name="livehelpnow_buttonid"
type="text" value="<?php echo $livehelpnow_buttonid; ?>" /></label></p>
<p><label for="livehelpnow_title">LiveHelpNow Title <input name="livehelpnow_title"
type="text" value="<?php echo $livehelpnow_title; ?>" /></label></p>


<p><input type="hidden" id="livehelpnow_submit" name="livehelpnow_submit" value="1" />
<img src='http://www.livehelpnow.net/images/logo_livehelpnow.gif' border=0><br /><a href='http://www.livehelpnow.net/cp/account/signup.aspx' target='_new' style='font-size:14px; font-weight:bold;text-decoration:none;'><b>Get LiveHelpNow account</b></a><br /><a href="http://www.livehelpnow.net/products/live_chat_system/buttons/" target='_blank' style='font-size:14px;text-decoration:none;'>See available Live chat buttons</a>
</p>
